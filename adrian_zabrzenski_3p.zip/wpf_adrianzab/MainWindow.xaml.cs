﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Windows.Controls.Ribbon.Primitives;

namespace wpf_adrianzab
{
    public partial class MainWindow : Window
    {
        private double bok;
        private double rozmiar = 0;
        private double top = 0;
        private double bottom = 0;
        private const double krok = 5;
        private double rozmiarGora = 0;
        private double rozmiarDol = 0;
        private double angle = 0;

        public MainWindow()
        {
            InitializeComponent();
            WyczyscTxt();
        }
        private void ZerujWatosci()
        {
            top = 0;
            bottom = 0;
        }
        private void WyczyscTxt()
        {
            txtBok.Text = String.Empty;
            txtPole.Text = String.Empty;
            txtObwod.Text = String.Empty;
            txtBokDol.Text = String.Empty;
            txtBokGora.Text = String.Empty;
            txtBokD.Text = String.Empty;

        }


        private void DrawPolygon()
        {
            MyPolygon.Points.Clear();

            double halfSize = rozmiar / 2;

            if (rozmiarDol == 0)
            {
                Trojkat(top, halfSize, false);
            }
            else if (rozmiarGora == 0)
            {
                Trojkat(bottom, halfSize, true);
            }
            else
            {
                Kwadrat(top, bottom, halfSize);
            }
        }

        private void Trojkat(double offset, double halfSize, bool isBottomTriangle)
        {
            if (isBottomTriangle)
            {
                AddPoint(-halfSize + offset, halfSize); 
                AddPoint(halfSize - offset, halfSize);  
                AddPoint(0, -halfSize);                 
            }
            else
            {
                AddPoint(-halfSize + offset, -halfSize); 
                AddPoint(halfSize - offset, -halfSize);  
                AddPoint(0, halfSize);                   
            }
        }

        private void Kwadrat(double topOffset, double bottomOffset, double halfSize)
        {
            AddPoint(-halfSize + topOffset, -halfSize);
            AddPoint(halfSize - topOffset, -halfSize);
            AddPoint(halfSize - bottomOffset, halfSize);
            AddPoint(-halfSize + bottomOffset, halfSize);
        }

        private void AddPoint(double x, double y)
        {
            MyPolygon.Points.Add(new Point(x, y));
        }

        private double liczCentroid()
        {
            double centroid;
            if(rozmiarDol >= rozmiarGora)
            {
                centroid = (rozmiarDol + 2 * rozmiarGora) / (3 * (rozmiarDol + rozmiarGora));
            }
            else
            {
                centroid = (rozmiarGora + 2 * rozmiarDol) / (3 * (rozmiarGora - rozmiarDol));
            }
            return centroid;
        }

        private void AktualizujWymiar()
        {

            rozmiarDol = rozmiar - (2 * bottom);
            rozmiarGora = rozmiar - (2 * top);


            if (rozmiarDol < 0)
            {
                rozmiarDol = 0;
            }

            if (rozmiarGora < 0)
            {
                rozmiarGora = 0;
            }


            txtBokDol.Text = rozmiarDol.ToString();
            txtBokGora.Text = rozmiarGora.ToString();


            DrawPolygon();
            poleTrapezu(rozmiarGora, rozmiarDol, bok);
            obwTrapezu(rozmiarGora, rozmiarDol, bok);
        }


        private void btnG_Click(object sender, RoutedEventArgs e)
        {
            double polowa = rozmiar / 2;

            if (bottom > 0)
            {
                bottom -= krok;

                if (bottom < 0) bottom = 0;
            }
            else if (top < polowa)
            {
                top += krok;
            }

            AktualizujWymiar();
        }

        private void btnD_Click(object sender, RoutedEventArgs e)
        {
            double polowa = rozmiar / 2;


            if (top == 0 && bottom < polowa)
            {
                bottom += krok;
            }
            else if (top > 0)
            {
                top -= krok;

                if (top < 0) top = 0;
            }

            AktualizujWymiar();
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            var regex = new Regex(@"^[0-9]*(?:\,[0-9]*)?$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void txtBok_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (double.TryParse(txtBok.Text, out bok) && bok >= 0)
            {
                txtPole.Text = Math.Pow(bok, 2.0).ToString();
                txtObwod.Text = (bok * 4).ToString();
                lblKomunikat.Content = String.Empty;

            }
            else
            {
                lblKomunikat.Content = "Wpisz liczbę dodatnią";
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (cbPrzezroczysty.IsChecked.HasValue && cbPrzezroczysty.IsChecked.Value)
            {
                MyPolygon.Opacity = 0.5;
            }
            else
            {
                MyPolygon.Opacity = 1.0;
            }
        }

        private void rysujButton_Click(object sender, RoutedEventArgs e)
        {

            if (double.TryParse(txtBok.Text, out bok) && bok <= 380)
            {
                rozmiar = bok;
                rozmiarDol = bok;
                rozmiarGora = bok;
                ZerujWatosci();
                DrawPolygon();

                MyPolygon.Width = rozmiar;
                MyPolygon.Height = rozmiar;
                SolidColorBrush color = (SolidColorBrush)new BrushConverter().ConvertFromString(cmbKolory.Text);
                MyPolygon.Stroke = color;
                MyPolygon.Fill = color;
                MyPolygon.Opacity = (cbPrzezroczysty.IsChecked.Value) ? 0.5 : 1;
                txtBokDol.Text = txtBokGora.Text = txtBokD.Text = bok.ToString();
                MyPolygon.RenderTransformOrigin = new Point(0, (liczCentroid() - 0.5));
            }
            else
            {
                lblKomunikat.Content = "Brak danych lub zbyt duży bok";
            }
        }

        private void radioPokaz_Checked(object sender, RoutedEventArgs e)
        {
            MyPolygon.Visibility = Visibility.Visible;
        }

        private void radioUkryj_Checked(object sender, RoutedEventArgs e)
        {
            MyPolygon.Visibility = Visibility.Hidden;
        }

        private void btnPowieksz_Click(object sender, RoutedEventArgs e)
        {
            ZmienBok(krok);
            txtBokDol.Text = txtBokGora.Text = txtBokD.Text = bok.ToString();
        }

        private void btnZmniejsz_Click(object sender, RoutedEventArgs e)
        {
            ZmienBok(-krok);
            txtBokDol.Text = txtBokGora.Text = txtBokD.Text = bok.ToString();
        }

        private void ZmienBok(double zmiana)
        {
            if (double.TryParse(txtBok.Text, out bok) && bok + zmiana > 0)
            {
                bok += zmiana;
                rozmiar = bok;
                top = bottom = 0;
                txtBok.Text = bok.ToString();
                DrawPolygon();
            }
        }


        private void btnWyczysc_Click(object sender, RoutedEventArgs e)
        {
            WyczyscTxt();
            MyPolygon.Points.Clear();
            ZerujWatosci();
            rozmiar = 0;
            
        }


        private void poleTrapezu(double bokA, double bokB, double wysokosc)
        {
            double pole = ((bokA + bokB) * wysokosc) / 2;
            txtPole.Text = pole.ToString();
        }


        private void obwTrapezu(double bokA, double bokB, double wysokosc)
        {
            double obw;
            double roznica = Math.Abs(bokA - bokB);
            double bokD = Math.Sqrt(Math.Pow(roznica / 2, 2.0) + Math.Pow(wysokosc, 2.0));
            txtBokD.Text = bokD.ToString();
            obw = (2 * bokD) + bokA + bokB;
            txtObwod.Text = obw.ToString();
        }
        private void obracajFigure()
        {
            
            RotateTransform rotateTransform2 =
            new RotateTransform(angle);
            
            MyPolygon.RenderTransform = rotateTransform2;
        }


        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sliderValue = slider.Value;
            angle = sliderValue;
            obracajFigure();
        }
        
    }
}


